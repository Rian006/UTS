<?php
$id_petugas = $_GET['id_petugas'];
include "koneksi.php";

$qry = "SELECT * FROM petugas_perpustakaan WHERE id_petugas = '$id_petugas'";
$exec = mysqli_query($con, $qry);
$data = mysqli_fetch_assoc($exec);

?>
<style>
        body {
        font-family: Arial, sans-serif;
        background-color: #f2f2f2;
        }

        fieldset {
        border: 2px solid #333;
        padding: 10px;
        margin-bottom: 20px;
        }

        legend {
        font-size: 20px;
        font-weight: bold;
        margin-bottom: 10px;
        }

        table {
        border-collapse: collapse;
        margin-bottom: 20px;
        }

        td,
        th {
        padding: 10px;
        }

        th {
        background-color: #333;
        color: #fff;
        }

        .tabel {
        width: 100%;
        }

        .tabel td,
        .tabel th {
        border: 1px solid #333;
        }

        .tabel tr:nth-child(even) {
        background-color: #f2f2f2;
        }

        input[type="submit"],
        button {
        padding: 10px;
        background-color: brown;
        color: #fff;
        border: none;
        cursor: pointer;
        }

        input[type="submit"]:hover,
        button:hover {
        background-color: #444;
        }
    </style>
<form action="update.php" method="POST">
        <fieldset>
            <legend align = "center">Form edit data petugas perpustakaan</legend>
            <table align = "center">
                <tr>
                    <td>ID Petugas</td>
                    <td>:</td>
                    <td><input type="number" name="id_petugas" value="<?= $data['id_petugas'] ?>" readonly></td>
                </tr>
                <tr>
                    <td>Nama Petugas</td>
                    <td>:</td>
                    <td><input type="text" name="nama_petugas" value="<?= $data['nama_petugas'] ?>"></td>
                </tr>
                <tr>
                    <td>Gender</td>
                    <td>:</td>
                    <td>
                        <?php
                            if($data['gender'] == 1) {
                        ?>
                            <input type="radio" name="gender" value="1" checked> laki-laki
                            <input type="radio" name="gender" value="2"> Perempuan
                        <?php } else { ?>
                            <input type="radio" name="gender" value="1"> laki-laki
                            <input type="radio" name="gender" value="2" checked> Perempuan
                        <?php } ?>
                    </td>
                </tr>
                <tr>
                    <td>Alamat</td>
                    <td>:</td>
                    <td><input type="text" name="alamat" value="<?= $data['alamat'] ?>"></td>
                </tr>
                <tr>
                    <td>No. HP</td>
                    <td>:</td>
                    <td><input type="text" name="nohp" value="<?= $data['no_hp'] ?>"></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td><input type="submit" value="simpan"></td>
                </tr>
            </table>
        </fieldset>
    </form>