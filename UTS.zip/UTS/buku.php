<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Buku</title>
    <style>
        body {
        font-family: Arial, sans-serif;
        background-color: #f2f2f2;
        }

        fieldset {
        border: 2px solid #333;
        padding: 10px;
        margin-bottom: 20px;
        }

        legend {
        font-size: 20px;
        font-weight: bold;
        margin-bottom: 10px;
        }

        table {
        border-collapse: collapse;
        margin-bottom: 20px;
        }

        td,
        th {
        padding: 10px;
        }

        th {
        background-color: #333;
        color: #fff;
        }

        .tabel {
        width: 100%;
        }

        .tabel td,
        .tabel th {
        border: 1px solid #333;
        }

        .tabel tr:nth-child(even) {
        background-color: #f2f2f2;
        }

        input[type="submit"],
        button {
        padding: 10px;
        background-color: brown;
        color: #fff;
        border: none;
        cursor: pointer;
        }

        input[type="submit"]:hover,
        button:hover {
        background-color: #444;
        }
    </style>
</head>

<body>
    <form action="proses_b.php" method="POST">
        <fieldset>
            <legend align = "center">Form Input Data Buku</legend>
            <table align = "center">
                <tr>
                    <td>ID Buku</td>
                    <td>:</td>
                    <td><input type="number" name="id_buku"></td>
                </tr>
                <tr>
                    <td>Juduk Buku</td>
                    <td>:</td>
                    <td><input type="text" name="judul_buku"></td>
                </tr>
                <tr>
                    <td>Tahun Terbit</td>
                    <td>:</td>
                    <td><input type="number" name="tahun_terbit"></td>
                </tr>
                <tr>
                    <td>Stock</td>
                    <td>:</td>
                    <td><input type="number" name="stock"></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td><input type="submit" value="simpan"></td>
                </tr>
            </table>
        </fieldset>
    </form>
    <br>
    <h2 align = "center">Data Buku</h2>
    <table class="tabel">
        <tr>
            <th>ID Buku</th>
            <th>Judul Buku</th>
            <th>Tahun Terbiy</th>
            <th>Stock</th>
            <th>Act</th>
        </tr>
        <?php 
            include "koneksi.php";
            $qry = "SELECT * FROM buku";
            $exec = mysqli_query($con, $qry);

            while($data = mysqli_fetch_assoc($exec)){
        ?>
        <tr>
            <td><?= $data['id_buku'] ?></td>
            <td><?= $data['judul_buku'] ?></td>
            <td><?= $data['tahun_terbit'] ?></td>
            <td><?= $data['stock'] ?></td>
            <td>
               <a href="edit_b.php?id_buku=<?= $data['id_buku'] ?>"><button>Edit</button></a>
               <a href="delete_b.php?id_buku=<?= $data['id_buku'] ?>"><button>Delete</button></a>
            </td>
        </tr>
        <?php } ?>
    </table>
</body>

</html>