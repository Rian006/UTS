<?php

$con = mysqli_connect("localhost", "root", "", "ba214_db");