<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Petugas Perpustakaan</title>
    <style>
        body {
        font-family: Arial, sans-serif;
        background-color: #f2f2f2;
        }

        fieldset {
        border: 2px solid #333;
        padding: 10px;
        margin-bottom: 20px;
        }

        legend {
        font-size: 20px;
        font-weight: bold;
        margin-bottom: 10px;
        }

        table {
        border-collapse: collapse;
        margin-bottom: 20px;
        }

        td,
        th {
        padding: 10px;
        }

        th {
        background-color: #333;
        color: #fff;
        }

        .tabel {
        width: 100%;
        }

        .tabel td,
        .tabel th {
        border: 1px solid #333;
        }

        .tabel tr:nth-child(even) {
        background-color: #f2f2f2;
        }

        input[type="submit"],
        button {
        padding: 10px;
        background-color: brown;
        color: #fff;
        border: none;
        cursor: pointer;
        }

        input[type="submit"]:hover,
        button:hover {
        background-color: #444;
        }
    </style>
</head>

<body>
    <form action="proses.php" method="POST">
        <fieldset>
            <legend align = "center">Form Input Data Petugas Perpustakaan</legend>
            <table align = "center">
                <tr>
                    <td>ID Petugas</td>
                    <td>:</td>
                    <td><input type="number" name="id_petugas"></td>
                </tr>
                <tr>
                    <td>Nama Petugas</td>
                    <td>:</td>
                    <td><input type="text" name="nama_petugas"></td>
                </tr>
                <tr>
                    <td>Gender</td>
                    <td>:</td>
                    <td>
                        <input type="radio" name="gender" value="1"> laki-laki
                        <input type="radio" name="gender" value="2"> Perempuan
                    </td>
                </tr>
                <tr>
                    <td>Alamat</td>
                    <td>:</td>
                    <td><input type="text" name="alamat"></td>
                </tr>
                <tr>
                    <td>No. HP</td>
                    <td>:</td>
                    <td><input type="text" name="nohp"></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td><input type="submit" value="simpan"></td>
                </tr>
            </table>
        </fieldset>
    </form>
    <br>
    <h2 align = "center">Data Petugas Perpustakaan</h2>
    <table class="tabel">
        <tr>
            <th>ID Petugas</th>
            <th>Nama Petugas</th>
            <th>Gender</th>
            <th>Alamat</th>
            <th>No HP</th>
            <th>Act</th>
        </tr>
        <?php 
            include "koneksi.php";
            $qry = "SELECT * FROM petugas_perpustakaan";
            $exec = mysqli_query($con, $qry);

            while($data = mysqli_fetch_assoc($exec)){
        ?>
        <tr>
            <td><?= $data['id_petugas'] ?></td>
            <td><?= $data['nama_petugas'] ?></td>
            <td><?= $data['gender'] == 1 ? "Laki-Laki" : "Perempuan" ?></td>
            <td><?= $data['alamat'] ?></td>
            <td><?= $data['no_hp'] ?></td>
            <td>
               <a href="edit.php?id_petugas=<?= $data['id_petugas'] ?>"><button>Edit</button></a>
               <a href="delete.php?id_petugas=<?= $data['id_petugas'] ?>"><button>Delete</button></a>
            </td>
        </tr>
        <?php } ?>
    </table>
</body>

</html>