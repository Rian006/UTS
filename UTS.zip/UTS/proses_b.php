<?php

$id_buku = $_POST['id_buku'];
$judul_buku = $_POST['judul_buku'];
$tahun_terbit = $_POST['tahun_terbit'];
$stock = $_POST['stock'];

include "koneksi.php";

$qry = "INSERT INTO buku VALUES (
    '$id_buku', '$judul_buku', '$tahun_terbit', '$stock'
)";

$exec = mysqli_query($con, $qry);

if($exec){
    echo "<script>alert('Data berhasil di simpan'); window.location = 'buku.php';</script>";
}else{
    echo "Data gagal di simpan";
}