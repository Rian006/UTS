<?php

$id_petugas = $_POST['id_petugas'];
$nama_petugas = $_POST['nama_petugas'];
$gender = $_POST['gender'];
$alamat = $_POST['alamat'];
$no_hp = $_POST['nohp'];

include "koneksi.php";

$qry = "UPDATE petugas_perpustakaan SET 
        nama_petugas = '$nama_petugas',
        gender = '$gender',
        alamat = '$alamat',
        no_hp = '$no_hp'
        WHERE id_petugas = '$id_petugas'
        ";

$exec = mysqli_query($con, $qry);

if($exec){
    echo "<script>alert('Data berhasil di update'); window.location = 'petugas.php';</script>";
}else{
    echo "Data gagal di simpan";
}