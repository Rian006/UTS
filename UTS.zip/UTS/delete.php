<?php

$id_petugas = $_GET['id_petugas'];

include "koneksi.php";
$qry = "DELETE FROM petugas_perpustakaan WHERE id_petugas = '$id_petugas'";
$exec = mysqli_query($con, $qry);

if($exec){
    echo "<script>alert('Data berhasil dihapus'); window.location = 'petugas.php'</script>";
}else{
    echo "Data gagal dihapus";
}