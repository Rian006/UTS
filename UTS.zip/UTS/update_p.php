<?php

$nim = $_POST['nim'];
$nama_mhs = $_POST['nama'];
$tgl_pinjam = $_POST['tgl_pinjam'];
$jurusan = $_POST['jurusan'];
$gender = $_POST['gender'];
$alamat = $_POST['alamat'];
$no_hp = $_POST['nohp'];

include "koneksi.php";

$qry = "UPDATE peminjam_buku SET 
        nama_mhs = '$nama_mhs',
        tgl_pinjam = '$tgl_pinjam',
        kode_jurusan = '$jurusan',
        gender = '$gender',
        alamat = '$alamat',
        no_hp = '$no_hp'
        WHERE nim = '$nim'
        ";

$exec = mysqli_query($con, $qry);

if($exec){
    echo "<script>alert('Data berhasil di update'); window.location = 'peminjam.php';</script>";
}else{
    echo "Data gagal di simpan";
}