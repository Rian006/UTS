<?php
$nim = $_GET['nim'];
include "koneksi.php";

$qry = "SELECT * FROM peminjam_buku WHERE nim = '$nim'";
$exec = mysqli_query($con, $qry);
$data = mysqli_fetch_assoc($exec);

?>
<style>
        body {
        font-family: Arial, sans-serif;
        background-color: #f2f2f2;
        }

        fieldset {
        border: 2px solid #333;
        padding: 10px;
        margin-bottom: 20px;
        }

        legend {
        font-size: 20px;
        font-weight: bold;
        margin-bottom: 10px;
        }

        table {
        border-collapse: collapse;
        margin-bottom: 20px;
        }

        td,
        th {
        padding: 10px;
        }

        th {
        background-color: #333;
        color: #fff;
        }

        .tabel {
        width: 100%;
        }

        .tabel td,
        .tabel th {
        border: 1px solid #333;
        }

        .tabel tr:nth-child(even) {
        background-color: #f2f2f2;
        }

        input[type="submit"],
        button {
        padding: 10px;
        background-color: brown;
        color: #fff;
        border: none;
        cursor: pointer;
        }

        input[type="submit"]:hover,
        button:hover {
        background-color: #444;
        }
    </style>
<form action="update_p.php" method="POST">
        <fieldset>
            <legend align = "center">Form Edit Data Peminjam Buku</legend>
            <table align = "center">
                <tr>
                    <td>NIM (Nomor induk mahasiswa)</td>
                    <td>:</td>
                    <td><input type="number" name="nim" value="<?= $data['nim'] ?>" readonly></td>
                </tr>
                <tr>
                    <td>Nama mahasiswa</td>
                    <td>:</td>
                    <td><input type="text" name="nama" value="<?= $data['nama_mhs'] ?>"></td>
                </tr>
                <tr>
                    <td>Tanggal Pinjam</td>
                    <td>:</td>
                    <td><input type="text" name="tgl_pinjam" value="<?= $data['tgl_pinjam'] ?>"></td>
                </tr>
                <tr>
                    <td>Jurusan</td>
                    <td>:</td>
                    <td><select name="jurusan">
                            <option value="001">Sistem Komputer</option>
                            <option value="002">Sistem Informasi</option>
                            <option value="003">Teknologi Informasi</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Gender</td>
                    <td>:</td>
                    <td>
                        <?php
                            if($data['gender'] == 1) {
                        ?>
                            <input type="radio" name="gender" value="1" checked> laki-laki
                            <input type="radio" name="gender" value="2"> Perempuan
                        <?php } else { ?>
                            <input type="radio" name="gender" value="1"> laki-laki
                            <input type="radio" name="gender" value="2" checked> Perempuan
                        <?php } ?>
                    </td>
                </tr>
                <tr>
                    <td>Alamat</td>
                    <td>:</td>
                    <td><input type="text" name="alamat" value="<?= $data['alamat'] ?>"></td>
                </tr>
                <tr>
                    <td>No. HP</td>
                    <td>:</td>
                    <td><input type="text" name="nohp" value="<?= $data['no_hp'] ?>"></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td><input type="submit" value="simpan"></td>
                </tr>
            </table>
        </fieldset>
    </form>