<?php
$id_buku = $_GET['id_buku'];
include "koneksi.php";

$qry = "SELECT * FROM buku WHERE id_buku = '$id_buku'";
$exec = mysqli_query($con, $qry);
$data = mysqli_fetch_assoc($exec);

?>
<style>
        body {
        font-family: Arial, sans-serif;
        background-color: #f2f2f2;
        }

        fieldset {
        border: 2px solid #333;
        padding: 10px;
        margin-bottom: 20px;
        }

        legend {
        font-size: 20px;
        font-weight: bold;
        margin-bottom: 10px;
        }

        table {
        border-collapse: collapse;
        margin-bottom: 20px;
        }

        td,
        th {
        padding: 10px;
        }

        th {
        background-color: #333;
        color: #fff;
        }

        .tabel {
        width: 100%;
        }

        .tabel td,
        .tabel th {
        border: 1px solid #333;
        }

        .tabel tr:nth-child(even) {
        background-color: #f2f2f2;
        }

        input[type="submit"],
        button {
        padding: 10px;
        background-color: brown;
        color: #fff;
        border: none;
        cursor: pointer;
        }

        input[type="submit"]:hover,
        button:hover {
        background-color: #444;
        }
    </style>
<form action="update_b.php" method="POST">
        <fieldset>
            <legend align = "center">Form Edit Data Buku</legend>
            <table align = "center">
                <tr>
                    <td>ID Buku</td>
                    <td>:</td>
                    <td><input type="number" name="id_buku" value="<?= $data['id_buku'] ?>" readonly></td>
                </tr>
                <tr>
                    <td>Judul Buku</td>
                    <td>:</td>
                    <td><input type="text" name="judul_buku" value="<?= $data['judul_buku'] ?>"></td>
                </tr>
                <tr>
                    <td>Tahun Terbit</td>
                    <td>:</td>
                    <td><input type="number" name="tahun_terbit" value="<?= $data['tahun_terbit'] ?>"></td>
                </tr>
                <tr>
                    <td>Stock</td>
                    <td>:</td>
                    <td><input type="number" name="stock" value="<?= $data['stock'] ?>"></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td><input type="submit" value="simpan"></td>
                </tr>
            </table>
        </fieldset>
    </form>