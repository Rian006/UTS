<?php

$id_petugas = $_POST['id_petugas'];
$nama_petugas = $_POST['nama_petugas'];
$gender = $_POST['gender'];
$alamat = $_POST['alamat'];
$no_hp = $_POST['nohp'];

include "koneksi.php";

$qry = "INSERT INTO petugas_perpustakaan VALUES (
    '$id_petugas', '$nama_petugas', '$gender', '$alamat', '$no_hp'
)";

$exec = mysqli_query($con, $qry);

if($exec){
    echo "<script>alert('Data berhasil di simpan'); window.location = 'petugas.php';</script>";
}else{
    echo "Data gagal di simpan";
}