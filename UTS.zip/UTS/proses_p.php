<?php

$nim = $_POST['nim'];
$nama_mhs = $_POST['nama'];
$tgl_pinjam = $_POST['tgl_pinjam'];
$jurusan = $_POST['jurusan'];
$gender = $_POST['gender'];
$alamat = $_POST['alamat'];
$no_hp = $_POST['nohp'];

include "koneksi.php";

$qry = "INSERT INTO peminjam_buku VALUES (
    '$nim', '$nama_mhs', '$tgl_pinjam', '$jurusan', '$gender', '$alamat', '$no_hp'
)";

$exec = mysqli_query($con, $qry);

if($exec){
    echo "<script>alert('Data berhasil di simpan'); window.location = 'peminjam.php';</script>";
}else{
    echo "Data gagal di simpan";
}