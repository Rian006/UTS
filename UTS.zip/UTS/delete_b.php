<?php

$id_buku = $_GET['id_buku'];

include "koneksi.php";
$qry = "DELETE FROM buku WHERE id_buku = '$id_buku'";
$exec = mysqli_query($con, $qry);

if($exec){
    echo "<script>alert('Data berhasil dihapus'); window.location = 'buku.php'</script>";
}else{
    echo "Data gagal dihapus";
}